"""
C2 Framework - Main Application

This is the entry point for the FastAPI application.
Includes background task for automatic agent cleanup.
"""

import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.database import engine
from app.models.database.base import Base
from app.api.routes import agents, tasks, auth, operators, generator
from app.models.database import agent, task, result, operator
from app.services.agent_cleanup import cleanup_loop


# ============================================
# LIFESPAN CONTEXT MANAGER
# ============================================
@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager for startup and shutdown events.
    
    This replaces the old @app.on_event("startup") and @app.on_event("shutdown")
    decorators with a more modern context manager approach.
    """
    # STARTUP
    print("=" * 60)
    print(f"✅ {settings.PROJECT_NAME} starting up...")
    print(f"✅ Database: {settings.POSTGRES_SERVER}:{settings.POSTGRES_PORT}/{settings.POSTGRES_DB}")
    print(f"✅ API docs: http://localhost:8000{settings.API_V1_STR}/docs")
    print("=" * 60)
    
    # Start background cleanup task
    cleanup_task = asyncio.create_task(cleanup_loop())
    print("🧹 Agent cleanup task started (runs every 60 seconds)")
    print("   - Marks agents inactive after 5 minutes")
    print("   - Marks agents dead after 30 minutes")
    print("   - Deletes dead agents after 7 days")
    print("=" * 60)
    
    yield  # Application runs here
    
    # SHUTDOWN
    print("=" * 60)
    print("👋 Shutting down C2 Framework...")
    cleanup_task.cancel()
    try:
        await cleanup_task
    except asyncio.CancelledError:
        print("🧹 Cleanup task stopped")
    print("=" * 60)


# ============================================
# CREATE FASTAPI APPLICATION
# ============================================
app = FastAPI(
    title=settings.PROJECT_NAME,
    version="1.0.0",
    description="Command and Control Framework - Educational Purpose Only",
    docs_url=f"{settings.API_V1_STR}/docs",
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    lifespan=lifespan  # Add lifespan context manager
)


# ============================================
# CORS MIDDLEWARE
# ============================================
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================
# ROOT ENDPOINTS
# ============================================
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": f"{settings.PROJECT_NAME} API",
        "version": "1.0.0",
        "docs": f"{settings.API_V1_STR}/docs",
        "status": "operational"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": settings.PROJECT_NAME
    }


# ============================================
# INCLUDE ROUTERS
# ============================================
app.include_router(
    auth.router,
    prefix=f"{settings.API_V1_STR}/auth",
    tags=["authentication"]
)

app.include_router(
    agents.router,
    prefix=f"{settings.API_V1_STR}/agents",
    tags=["agents"]
)

app.include_router(
    tasks.router,
    prefix=f"{settings.API_V1_STR}/tasks",
    tags=["tasks"]
)

app.include_router(
    operators.router,
    prefix=f"{settings.API_V1_STR}/operators",
    tags=["operators"]
)

app.include_router(
    generator.router,
    prefix=f"{settings.API_V1_STR}/generator",
    tags=["generator"]
)


# ============================================
# RUN APPLICATION
# ============================================
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=8000, 
        reload=True
    )